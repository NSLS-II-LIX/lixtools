from .generic import display_data_h5xs
from .sol_static import display_solHT_data
from .sol_hplc import display_HPLC_data,HPLC_GUI_par
from .sol_hplc_mcr import performMCR